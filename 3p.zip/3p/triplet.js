function char() {
    let numbers = ['30', '-40', '-20', '-10', '40', '0', '10', '5'];

    for(let i = 0;i <= numbers.length; i++){
        for(let j = i+1;j <= numbers.length; j++){          
            for(let k = k+1;k <= numbers.length; k++){     
            }   
        }
    }

}
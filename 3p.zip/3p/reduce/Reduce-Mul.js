//onArray : multplier

var array = [4,8,15,16,23,42]
let mul = function(a,b){return a*b}

array.reduce(mul,1);

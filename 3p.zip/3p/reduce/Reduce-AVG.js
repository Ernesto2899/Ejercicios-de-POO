//onArray : avg

const myArray = [1,2,3,12,9,57]
const sum = (x,y) => x+y
const avg = myArray =>
    myArray.reduce(sum,0) / myArray.length
console.log(avg(myArray))
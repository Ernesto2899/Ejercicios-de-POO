class Circle{
    constructor(x,y){
        this.x=x;
        this.y=y;

    };
    toString(){return "(Point: "+this.x.x+" ,"+this.x.y+" , Radious: "+this.y+")";};
    

};
module.exports = Circle;
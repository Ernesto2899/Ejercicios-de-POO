var Module = {
    methodOne : function(){
        console.log('We are performing a very complex task(1)...');
    },
    methodTwo : function(){
        console.log('We are performing a very complex task(2)...');
    }
}
function countChars(obj){    
    document.getElementById("charNum").innerHTML = obj.value.length+' Leters';
    
  } 
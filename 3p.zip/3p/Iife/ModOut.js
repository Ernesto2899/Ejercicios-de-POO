    // object literal : methods outside

var Module = {}

    Module.methodOne = function(){
        console.log('We are performing a very complex task(1)...');
    }
    Module.methodTwo = function(){
        console.log('We are performing a very complex task(2)...');
    }
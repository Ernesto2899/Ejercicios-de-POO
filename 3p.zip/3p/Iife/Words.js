function countChars(obj){    
    document.getElementById('cont').innerHTML = obj.value.split(" ").length + ' Words';
    
  } 
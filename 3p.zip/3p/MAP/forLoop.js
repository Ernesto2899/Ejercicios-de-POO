//doubles using forLoop

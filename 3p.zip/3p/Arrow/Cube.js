let cube = (a) => a*a*a

cube(1)
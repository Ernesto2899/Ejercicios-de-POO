let square = (a) => a*a

square(1)
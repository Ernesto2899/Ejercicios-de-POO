let multiply = (a,b) => a*b

multiply(1,2)
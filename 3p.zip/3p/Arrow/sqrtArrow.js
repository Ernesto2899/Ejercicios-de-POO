//
let sqrt = (a) => Math.sqrt(a)

sqrt(25)
let empty = () => {}//returns undefined

( () => "pine" )(); //returns "pine"

let max = (a,b) => a>b ?a :b;

let simple = a => a>10 ?10 :a;






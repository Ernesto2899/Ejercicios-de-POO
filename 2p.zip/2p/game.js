class Dog{}

class Cat{}

class Hero{}

class Enemy{}

class Game{}


g = new Game()

class Game{
    one(){console.log('performing a complex tasks...');}
    two(){};
    three(){};
};

g = new Game()

g1= new Game()

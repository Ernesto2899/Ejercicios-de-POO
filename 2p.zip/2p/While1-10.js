var i=0;

while(i<10){
    i++;//i=i+1
    console.log(i);
}
console.log('done...');



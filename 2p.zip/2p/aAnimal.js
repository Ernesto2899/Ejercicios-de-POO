var aAnimal = {//literal objects
    name: 'starling',
    gender : 'female',
    hasFur : false,
      breaths :true
}

aAnimal.hasWings=true;

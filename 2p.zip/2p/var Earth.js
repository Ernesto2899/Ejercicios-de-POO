var Earth = new Object();
Earth.diameter = '7920 miles';
Earth.distance = '93 million miles';
Earth.year ='365.25';
Earth.day ='24 hours';

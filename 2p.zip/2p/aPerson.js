var aPerson = {//literak objects
first : 'first name',
second : 'second name',
age : 0,
gender : 'male'
};

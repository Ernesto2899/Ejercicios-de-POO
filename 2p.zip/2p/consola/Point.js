class Point {
    constructor (x,y){
	this.x = x;
	this.y = y;
	print('Geometry->Point->constructor')
    };

    draw(){console.log('draw Point');};////other
    clone(){};


    get x(){return this._x;}
    get y(){return this._y}
    set x(x){this.x=x}
    set y(y){this._y=y}

    toString(){return "("+"this.x"+ "this.y"+")";};
    distance(p){}
     clone(){return new Point(this.x,this.y);};
    };

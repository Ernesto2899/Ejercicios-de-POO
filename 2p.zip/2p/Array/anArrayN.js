var array1 = [];//recomended
var array2 = new Array();

let anArray = [-3, -2, -1]
array1.push(-3)
array1

for (let k=0; k<anArray.length; k++){
    console.log(anArray[k]);
}

for (let x of anArray){
    console.log(x);
}

let arr = [2, 3, -4, 5, 6];

let t=arr[0]//2//-4
for (let x of arr) {
    if (t<x)
    t=x
}
conssole.log(t);

function vectorial();
var size=10
let a=0
let b=1
n=10
let i=(b-a)/n

for (let i=0; i<size.length; i++ ){
    a+=i
}
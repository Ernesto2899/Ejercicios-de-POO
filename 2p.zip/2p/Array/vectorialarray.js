let a=0
let b=1
let c=10
let i=(b-a)/c
let anArray= [];

for (let z=0; z<10; z++ ){
    a+=i
	anArray.push(a)
console.log(anArray[z]);
}
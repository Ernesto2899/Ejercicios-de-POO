
    class Fraction {
	constructor(n, d) {   //validate: n,d
	    this.n = n;
	    this.d = d;

	};

	euclides(n,d){return d;};
	sum(f){  };
	subt(f){  };
	div(f){  };
	mul(f){//validate
	    var n = this.n * f.n;
	    var d = this.d * f.d;
	    //euclides HERE
	    return new Fraction(n,d);
	};
    };

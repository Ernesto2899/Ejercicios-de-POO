var careful =3.1
careful
careful = 1.3// watch out
careful
var careful = null//worst
careful

let price = 120.25
price
let price = 20.125//SyntaxError, jsshell
price = 110.12
price
price = null
price

const tax = 0.825
const tax = 0.825//SyntaxError
tax
tax = 1.25


const sam = {first: 'Sam', age:2}
sam
const sam = {}//SyntaxError
sam.age = 3//however
sam

const greet= 'dude'
greet
greet[0] = 'r'//String are immutable
typeof greet

const pearl = Object.freeze({first: 'pearl', age: 1})
pearl
const pearl = {}//SyntaxError
pearl.age =3//note
pearl

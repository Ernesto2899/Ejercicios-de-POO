class Robot {
    constructor(name){
    this.name = name;
    };
    
    
    speak(){};
    makecoffee(){};
    blinkLight(){};
};

var a = new Robot('aRobot');

 class Fraction {
	constructor(n, d) {   //validate: n,d
	    this.n = n;
	    this.d = d;

	};

	mul(f){//validate
	    var n = this.n * f.n;
	    var d = this.d * f.d;
	    // euclides HERE
	    return new Fraction(n,d)
	};
    };
    f1 = new Fraction(4,2)
    f2 = new Fraction(5,4)

var i=1;
do{print(i);
   i++;
  }while(i<11);
print('done...');

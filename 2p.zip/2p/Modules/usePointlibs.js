load('../../libs/ejrm/Geometry/Point.js');

p=new Point(3, 4);
q = new Point(-3, -4);

print(p.toString());
//console.log(p.toString());

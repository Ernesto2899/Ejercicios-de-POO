var Cat = {//literal objetcs
    name: 'Michi',
    getName: function(){//usign functions
    return this.name;
    },
    talk:function(){
    console.log('Miaw, miaw');
    }
};

var Padre = {//literal objetcs
    name: 'SR.Heriberto',
    getName: function(){//usign functions
    return this.name;
    },
    talk:function(){
    console.log('Soy el padre de familia');
    }
};

var Madre = {//literal objetcs
    name: 'Consuelo',
    getName: function(){//usign functions
    return this.name;
    },
    talk:function(){
    console.log('Soy la madre');
    }
};

var Yo = {//literal objetcs
    name: 'Heriberto',
    getName: function(){//usign functions
    return this.name;
    },
    talk:function(){
    console.log('Hola, soy Heriberto Figueroa');
    }
};

var Hermana = {//literal objetcs
    name: 'Camila',
    getName: function(){//usign functions
    return this.name;
    },
    talk:function(){
    console.log('Soy la hermana');
    }
};
var Tia = {//literal objetcs
    name: 'Rosa',
    getName: function(){//usign functions
    return this.name;
    },
    talk:function(){
    console.log('Soy la tia');
    }
};


class Robot {
    constructor(name){
    this.name = name;
    };
    
    
    speak(){Console.log('speaking...')};
    makecoffee(){Console.log('Making coffe now...')};
    blinkLight(){Console.log('Blinkinglight now...')};
};

var a = new Robot('aRobot');

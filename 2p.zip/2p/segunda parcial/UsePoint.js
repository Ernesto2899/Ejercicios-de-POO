
const Point = require('../Programas/PA/Point2')

let HeribertoPUNTO = new Point(2,3)

console.log(HeribertoPUNTO.toString())
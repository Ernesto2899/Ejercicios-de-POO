var Dog = {//literal objetcs
    name: 'Cacha',
    getName: function(){//usign functions
    return this.name;
    },
    talk:function(){
    console.log('ruf, ruf');
    }
};

var Father = {//literal objetcs
    name: 'Isaac Macia',
    getName: function(){//usign functions
    return this.name;
    },
    talk:function(){
    console.log('Soy el patriarca de la familia');
    }
};

var Mother = {//literal objetcs
    name: 'Anel',
    getName: function(){//usign functions
    return this.name;
    },
    talk:function(){
    console.log('Soy la madre');
    }
};

var Me = {//literal objetcs
    name: 'Ernesto',
    getName: function(){//usign functions
    return this.name;
    },
    talk:function(){
    console.log('Hello, Im Ernesto');
    }
};

var Brother = {//literal objetcs
    name: 'Isaac',
    getName: function(){//usign functions
    return this.name;
    },
    talk:function(){
    console.log('Soy el hermano');
    }
};
var Grandma = {//literal objetcs
    name: 'Martha',
    getName: function(){//usign functions
    return this.name;
    },
    talk:function(){
    console.log('Im the Grandmother');
    }
};
class Cuadrado {
    constructor(puntoA){
        this.puntoA = puntoA;
        
    }
    toString(){
        console.log('Punto A: '+ this.puntoA.x +','+ this.puntoA.y)
    }

}
module.exports=Cuadrado
class Fraction{
    constructor(n,d){
        this.n = n;
        this.d = d;
    }
    euclides(n,d){


    }
    sum(f){
        let n=this.

        
    }


























}
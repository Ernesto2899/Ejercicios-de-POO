var i=0;

while(i<5){
    i++;//i=i+1
    console.log(i);
}
console.log('done...');



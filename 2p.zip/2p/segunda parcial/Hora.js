class Hora{
    constructor(segundos,minutos,hora){
    this.segundos = segundos
    this.minutos = minutos;
    this.hora = hora;
    }
    

    getTimesegundos= function() {
       return this.segundos;
    }
    
    getTimeminutos= function(){
        return this.minutos ;
    }
    
     getTimehora= function(){
        return this.hora;
    }

    set Valores(array){
        arrayValores();
        this.segundos = arrayValores[59];
        this.minutos = arrayValores[59];
        this.hora = arrayValores[23];
    }


}if(typeof segundos = ){

}
toString(){
    return this.segundos;

}
toString(){
return this.minutos;
}
toString(){
    return this.hora;
}




console.log(hora+':'+minutos+':'+segundos )
tick()
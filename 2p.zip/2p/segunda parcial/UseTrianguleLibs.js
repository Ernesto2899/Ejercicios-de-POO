const Point = require('../Programas/PA/Point2')

const Triangule = require('../Programas/PA/Triangulo')

p1 = new Point(2,3)
p2 = new Point(2,1)
p3 = new Point(4,3)

let Tri = new Triangule(p1,p2,p3)

console.log(Tri)


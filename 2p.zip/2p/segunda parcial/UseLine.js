const Point = require('../Programas/PA/Point2')

const Line =  require('../Programas/PA/Line')

let p1 = new Point(6,9);
let p2 = new Point(8,8);

let NewLinea = new Line(p1,p2)

NewLinea.toString()
const Circulo = require('../segunda parcial/USE/Circulo')

const Point = require('../segunda parcial/USE/Point2')

let p1 = new Point(2,3)
let R = 5

let NewCirculo = new Circulo(p1,R)

NewCirculo.tostring()
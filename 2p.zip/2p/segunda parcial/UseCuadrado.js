const Point = require('../segunda parcial/USE/Point2')

const Cuadrado = require('../segunda parcial/USE/Cuadrado')

let p1 = new Point(4,4);

let square = new Cuadrado(p1)

square.toString()
var aRobot ={//literal objects
    name: 'c3po',
    partnerof : 'r2d2'
};

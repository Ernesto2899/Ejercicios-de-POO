var aPoint = {//literal object
     x:3,
     y:4
}

var bPoint = {//literal object
     x:-3,
     y:-4
}

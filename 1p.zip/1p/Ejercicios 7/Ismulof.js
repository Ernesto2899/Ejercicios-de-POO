function isInteger(n){

var numero1=3;
var numero2=5;

resto = numero1%numero2;
 
if (resto==0)
  return true;
else
  return false;
}


print(isInteger(numero1*numero2))

function isMultiple(v,m )
        {
            var resto = v % m;
            if(resto==0)
                return true;
            else
                return false;
        }
print(isMultiple(6,3))
print(isMultiple(3,6))

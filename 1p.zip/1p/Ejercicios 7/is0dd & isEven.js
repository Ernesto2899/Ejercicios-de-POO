function is0dd(n){
if(n%2!==0)
return true
else
return false
}

function isEven(n){
return !is0dd(n)
}
print(is0dd(33))
print(isEven(6))
print(isEven(3))
print(is0dd(20))

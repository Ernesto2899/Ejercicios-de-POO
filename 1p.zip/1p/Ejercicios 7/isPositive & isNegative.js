function isPositive(n){
if(n>=0)
return true
else
return false
}

function isNegative(n){
if(n<0)
return true
else
return false
}

print(isNegative(0))
print(isPositive(1))
print(isPositive(0))
print(isPositive(0))
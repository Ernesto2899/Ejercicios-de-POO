function isInteger(n){
if(n%1==0)
return true
else
return false
}



print(isInteger(-0.133))
print(isInteger(12.1))
print(isInteger(-2))
print(isInteger(35))

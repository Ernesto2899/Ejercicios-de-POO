var x =0;
for(var i=32; i>20;i--){
     if(i%2 ==0){
         x++;    
    }     
 }
print(x);

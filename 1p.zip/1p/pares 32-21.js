var i=20;
var A=0;
while(i<32){
      i++;//i=i+1


if(i%2==0){
     A=A+1;
}
 print(i);
}
print("Hay "+ A +" pares");
print('done...');

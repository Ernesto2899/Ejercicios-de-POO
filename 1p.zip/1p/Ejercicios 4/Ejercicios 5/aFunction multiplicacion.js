
function mult(a,b){
    return a*b;
}

print(mult(1,2));

    
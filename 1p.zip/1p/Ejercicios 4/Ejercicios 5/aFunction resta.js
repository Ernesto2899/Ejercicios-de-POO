
function rest(a,b){
    return a-b;
}

print(rest(1,2));

    
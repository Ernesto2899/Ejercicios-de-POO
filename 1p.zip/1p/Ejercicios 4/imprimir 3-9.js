var i=2;
var A=0;
while(i<9){
      i++;//i=i+1
      print(i);


} 
print('done...');
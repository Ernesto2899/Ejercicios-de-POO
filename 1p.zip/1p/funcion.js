for(var i =1; i<11;i++){
     print(i/3);
}



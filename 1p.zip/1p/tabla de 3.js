for(var i=1;i<11;i++)
{
mult =3*i;

print(mult);}

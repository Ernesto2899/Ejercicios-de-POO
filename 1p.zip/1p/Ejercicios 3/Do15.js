var i=1;
do{print(i);
   i++;
  }while(i<6);
print('done...');

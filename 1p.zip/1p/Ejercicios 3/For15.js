for(var i=1;i<6;++i){ 
    print(i);
}

var i=5;
do{print(i);
   i++;
  }while(i<10);
print('done...');

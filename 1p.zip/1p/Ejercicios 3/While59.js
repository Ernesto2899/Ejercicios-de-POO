var i=4;

while(i<9){
    i++;//i=i+1
    print(i);
}
print('done...');



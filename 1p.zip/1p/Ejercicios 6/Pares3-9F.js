var isNumber = function(x) {
    
    if (typeof x === 'number')
	return true;
    else
	return false;
}

function Pares39F(){
for(var i=3;i<9;++i)
{
	i = i + 1;
print(i);
}
}
print(Pares39F())
print('done..')
a=5
b=8
c=12
s=(a+b+c)*(.5)
r=(s)*(s-a)*(s-b)*(s-c)
t=Math.sqrt(r)
print('Radio del circulo es= '+t/s)

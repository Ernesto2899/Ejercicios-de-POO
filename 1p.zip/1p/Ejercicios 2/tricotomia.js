a=6
b=7

if(a<b) 
    print(a+' es menor que '+b)
else if(a>b) 
    print(a+' es mayor que '+b)
else if(a=b) 
    print(a+' es igual que '+b)
b=3
h=5
a=(b*h)/2
print('a: '+a)

l=3
a=(l*l)
print('Area= '+a)

pi=3.1415
r=5
a=(pi*r*r)
print('Area= '+a)

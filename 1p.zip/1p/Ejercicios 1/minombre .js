print('Hola Ernesto De Jesus Ramirez Martinez')
print('Armeria, Colima')

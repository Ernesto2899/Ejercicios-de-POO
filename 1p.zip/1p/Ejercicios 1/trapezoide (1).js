b=3
a=5
h=5
a=h*(a+b)/2
print('Area= '+a)

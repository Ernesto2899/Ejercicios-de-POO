print('VideoJuegos')
print('Aprender sobre Historia')
print('¨Hacer¨Deporte y Dieta')

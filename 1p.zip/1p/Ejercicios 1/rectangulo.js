b=3
h=5
a=(b*h)
print('Area= '+a)

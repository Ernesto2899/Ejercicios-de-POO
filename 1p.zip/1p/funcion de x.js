for(var i=1;i<12;i++){
var divide =i/3;
print(divide);
}
